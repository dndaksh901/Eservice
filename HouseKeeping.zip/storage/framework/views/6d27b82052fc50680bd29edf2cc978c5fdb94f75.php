<?php $__env->startSection('links'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.4.0/css/responsive.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>
    div.container { max-width: 1200px }
    .dataTables_wrapper .dataTables_paginate .paginate_button {padding: 0;}
</style>
    <div class="content-wrapper container">
        <div class="row">
            <div class="col-12">
                <table id="enquiry-table" class="display nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th>Schedule Date</th>
                            <th>Client Name</th>
                            <th>Address</th>
                            <th>Phone</th>
                            <th>email</th>
                            <th>Budget</th>
                            <th>Note</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($enquiries): ?>
                          <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e(date('Y/m/d H:i:s',strtotime($enquiry->created_at))); ?></td>
                            <td><?php echo e($request->client_name ?? $request->user->firtname); ?></td>
                            <td><?php echo e($request->client_address); ?></td>
                            <td><?php echo e($request->client_phone ?? $request->user->phone); ?></td>
                            <td><?php echo e($request->client_email); ?></td>
                            <td><?php echo e($request->client_budget); ?></td>
                            <td><?php echo e($request->client_note); ?></td>

                            <?php  $color='text-warning'; ?>

                            <?php if($request->client_status == 2): ?>
                            <?php  $color='text-success'; ?>
                            <?php elseif($request->client_status == 3): ?>
                            <?php  $color='text-danger'; ?>
                            <?php elseif($request->client_status == 4): ?>
                            <?php  $color='text-danger'; ?>
                            <?php endif; ?>
                            <td class="<?php echo e($color); ?>"><?php echo e($request->client_status); ?></td>
                            <td>
                                <button class="btn btn-primary" onClick="changeStatus(2)">Accept</button>
                                <button class="btn btn-danger" onClick="changeStatus(3)">Decline</button>
                            </td>
                        </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="https://cdn.datatables.net/responsive/2.4.0/js/dataTables.responsive.min.js"></script>
  <script>
    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
    });

    $(document).ready(function () {
       var enquirytable = $('#enquiry-table').DataTable({
        responsive: true
    });

    function changeStatus(status){

        enquirytable.draw();
    }
});
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('vendor.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\htdocs\HouseKeeping\resources\views/vendor/enquiry.blade.php ENDPATH**/ ?>