<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Vendor Dashboard</title>
        <!-- plugins:css -->
        <link rel="stylesheet" href="<?php echo e(url('admin/vendors/feather/feather.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('admin/vendors/ti-icons/css/themify-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('admin/vendors/css/vendor.bundle.base.css')); ?>">
        <!-- endinject -->
        <!-- Plugin css for this page -->
        <link rel="stylesheet" href="<?php echo e(url('admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('admin/vendors/ti-icons/css/themify-icons.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('admin/js/select.dataTables.min.css')); ?>">

        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel="stylesheet" href="<?php echo e(url('admin/css/vertical-layout-light/style.css')); ?>">
        <!-- endinject -->
        <link rel="shortcut icon" href="<?php echo e(asset('admin/images/favicon.png')); ?>" />

        <?php echo $__env->yieldContent('links'); ?>

    </head>
    <body>
        <div class="container-scroller">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('vendor.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="container-fluid page-body-wrapper">
                <!-- partial:partials/_settings-panel.html -->
                <?php echo $__env->make('vendor.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- partial -->
            <div class="main-panel">
                <?php echo $__env->yieldContent('content'); ?>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
        </div>
        <!-- container-scroller -->
        <!-- plugins:js -->
        <script src="<?php echo e(url('admin/vendors/js/vendor.bundle.base.js')); ?>"></script>
        <!-- endinject -->
        <!-- Plugin js for this page -->
        <script src="<?php echo e(url('admin/vendors/chart.js/Chart.min.js')); ?>"></script>
        <script src="<?php echo e(url('admin/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
        <script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(url('admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/dataTables.select.min.js')); ?>"></script>
        <!-- End plugin js for this page -->
        <!-- inject:js -->
        <script src="<?php echo e(url('admin/js/off-canvas.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/hoverable-collapse.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/template.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/settings.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/todolist.js')); ?>"></script>
        <!-- endinject -->
        <!-- Custom js for this page-->
        <script src="<?php echo e(url('admin/js/dashboard.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/Chart.roundedBarCharts.js')); ?>"></script>
        <!-- End custom js for this page-->
        <!-- Select 2 js-->
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <!-- End Select 2 js-->
        <script>
            function cl(data){
                console.log(data);
            }
        </script>
        <?php echo $__env->yieldPushContent('script'); ?>
    </body>
</html>
<?php /**PATH F:\project\htdocs\HouseKeeping\resources\views/vendor/layout/layout.blade.php ENDPATH**/ ?>