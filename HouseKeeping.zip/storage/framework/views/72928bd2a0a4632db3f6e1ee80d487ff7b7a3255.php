<?php $__env->startSection('content'); ?>
    <style>
        .divider:after,
        .divider:before {
            content: "";
            flex: 1;
            height: 1px;
            background: #eee;
        }

        .h-custom {
            height: calc(100% - 73px);
        }

        @media (max-width: 450px) {
            .h-custom {
                height: 100%;
            }
        }
    </style>

    <div>
        <section class="card vh-100">
            <div class="container-fluid h-custom">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-md-9 col-lg-6 col-xl-5">
                        <img src="<?php echo e(asset('imgs/signup.png')); ?>" class="img-fluid" alt="Sample image">
                    </div>
                    <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                        <?php if(isset($url)): ?>
                            <form method="POST" action='<?php echo e(url("$url/register")); ?>' aria-label="<?php echo e(__('Register')); ?>">
                            <?php else: ?>
                                <form method="POST" action='<?php echo e(route('register')); ?>' aria-label="<?php echo e(__('Register')); ?>">
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <div
                                    class="d-flex flex-row align-items-center justify-content-center justify-content-lg-start">
                                    <h3 class="fw-bold text-center mb-3"><?php echo e(isset($url) ? ucwords($url) : ''); ?>

                                        <?php echo e(__('Register')); ?></h3>
                                </div>
                                <!-- Email input -->
                                <div class="form-outline mb-4">
                                    <input id="name" type="text"
                                        class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                        value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus
                                        placeholder="Enter Name">

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-outline mb-4">
                                    <input id="email" type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                        value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                        placeholder="Enter Email Address">

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Password input -->
                                <div class="form-outline mb-3">
                                    <input id="password" type="password"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" max="15"
                                        name="password" required autocomplete="new-password" placeholder="Enter Password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-outline mb-3">
                                    <input id="password-confirm" type="password" class="form-control"
                                        name="password_confirmation" required autocomplete="new-password"
                                        placeholder="Confirm Password">
                                </div>


                                <div class="text-center text-lg-start mt-4 pt-2">
                                    <button type="submit" class="btn btn-lg"
                                        style="padding-left: 2.5rem; padding-right: 2.5rem;background: var(--yellow-color);
                    border-color:var(--yellow-color);color:#ffffff;"><?php echo e(__('Register')); ?></button>
                                    <p class="small fw-bold mt-2 pt-1 mb-0">Have already an account?

                                        <?php if(isset($url)): ?>
                                            <a href="<?php echo e(url("$url/login")); ?>"
                                                class="link-danger"><?php echo e(isset($url) ? ucwords($url) : ''); ?>

                                                <?php echo e(__('Login')); ?></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('login')); ?>"
                                                class="link-danger"><?php echo e(isset($url) ? ucwords($url) : ''); ?>

                                                <?php echo e(__('Login')); ?></a>
                                        <?php endif; ?>

                                    </p>
                                </div>

                            </form>
                    </div>
                </div>
            </div>

        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\htdocs\HouseKeeping\resources\views/auth/register.blade.php ENDPATH**/ ?>