<?php $__env->startSection('content'); ?>
<style>
        img.profile-side-image{
        position: fixed;
        max-width: 41.5%;
        width: 100%;
    }
</style>
    <div class="content-wrapper">
        <div class="row">
            <?php if(session()->has('error')): ?>
                    <span class="alert alert-danger col-12">
                        <strong><?php echo e(session()->get('error')); ?></strong>
                    </span>
                <?php endif; ?>
                <?php if(session()->has('success')): ?>
                    <span class="alert alert-success col-12">
                        <strong><?php echo e(session()->get('success')); ?></strong>
                    </span>
                <?php endif; ?>
          </div>
      <div class="row">
        <div class="col-lg-6 col-md-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Update Vendor Password</h4>
              <form action="<?php echo e(url('vendor/update-current-password')); ?>" method="post" class="forms-sample">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="exampleInputUsername1">Username</label>
                  <input type="text" class="form-control" readonly value="<?php echo e(Auth::guard('vendor')->user()->username); ?>">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" class="form-control" readonly value="<?php echo e(Auth::guard('vendor')->user()->email); ?>">
                </div>
                <div class="form-group">
                  <label for="current_password">Password</label>
                  <input type="password" class="form-control" id="current_password" placeholder="Current Password" name="current_password" value="" onkeyup="checkCurrentPassword(this.value)" autocomplete="off" autofocus="off">
                  <p id="current_password_message"></p>
                  <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <label for="new_password">New Password</label>
                  <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="new_password" placeholder="Current Password" name="password">
                  <p id="current_password_message"></p>
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <label for="confirm_password">Confirm Password</label>
                  <input type="password"  class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" autocomplete="password_confirmation">
                  <p id="current_password_message"></p>
                  <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                <button class="btn btn-light">Cancel</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-12 col-sm-12">
            <div><img src="<?php echo e(asset('vendor/password-page.png')); ?>" alt="password-image" class="img-fluid profile-side-image"></div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script>
       $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        //Check current password
        function checkCurrentPassword(password){

             $.ajax({
                url:"<?php echo e(url('vendor/check-current-password')); ?>",
                type:"post",
                data:{
                   'current_password' : password
                },
                success:function(response){
                    cl(response);
                    $("#current_password_message").empty();

                    if(response.status == 200){
                        $("#current_password_message").html(`<span class="text-success font-weight-bold">${response.message}</span>`)
                    }else{
                        $("#current_password_message").html(`<span class="text-danger font-weight-bold">${response.message}</span>`)
                    }
                }
             });
        }

  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('vendor.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\htdocs\HouseKeeping\resources\views/vendor/update_password.blade.php ENDPATH**/ ?>