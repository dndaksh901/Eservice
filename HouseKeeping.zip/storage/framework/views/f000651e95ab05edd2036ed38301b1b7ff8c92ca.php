<header class="main_header">
    <nav class="navbar navbar-expand-md navbar-light primaryTopBar">
        <div class="container custom_container">
            <a class="navbar-brand" href="/">
                <img src="<?php echo e(asset('imgs/logo.webp')); ?>" srcset="<?php echo e(asset('imgs/logo.webp')); ?>" class="img-fluid brand_img" alt="Brand Logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#topNavbar">
                <i class="fas fa-bars togglerIcon"></i>
            </button>
            <div class="collapse navbar-collapse" id="topNavbar">
                <ul class="navbar-nav menuLists align-items-center">
                    <li class="nav-item top_under_submenu_logo">
                        <a class="nav-link" href="/">
                            <img src="<?php echo e(asset('imgs/logo-white.webp')); ?>" srcset="<?php echo e(asset('imgs/logo-white.webp')); ?>" class="img-fluid brand_img_submenu" alt="Brand Logo">
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Dropdown</a>
                        <ul class="dropdown-menu">
                          <li><a class="dropdown-item" href="#">Link</a></li>
                          <li><a class="dropdown-item" href="#">Another link</a></li>
                          <li><a class="dropdown-item" href="#">A third link</a></li>
                        </ul>
                      </li>
                    <li class="nav-item dropdown">


                            <?php if(!Auth::guard('vendor')->check() && !Auth::check()): ?>

                                <a class="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                  Account
                                </a>

                                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">

                                            <li class="nav-item">
                                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                            </li>

                                            <li class="nav-item">
                                                <a class="nav-link" href="<?php echo e(url('vendor/login')); ?>">Vendor Login</a>
                                            </li>


                                    </ul>

                                <?php endif; ?>

                            <?php if(Auth::guard('vendor')->check() ): ?>

                                          <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                              <?php echo e(Auth::guard('vendor')->user()->name); ?>

                                          </a>

                                          <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                              <a class="dropdown-item" href="<?php echo e(url('vendor/logout')); ?>"
                                                 onclick="event.preventDefault();
                                                               document.getElementById('logout-form').submit();">
                                                  <?php echo e(__('Logout')); ?>

                                              </a>

                                              <form id="logout-form" action="<?php echo e(url('vendor/logout')); ?>" method="get" class="d-none">
                                                  <?php echo csrf_field(); ?>
                                              </form>
                                          </div>


                <?php elseif(Auth::check()): ?>

                                          <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                              <?php echo e(Auth::user()->name); ?>

                                          </a>

                                          <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                 onclick="event.preventDefault();
                                                               document.getElementById('logout-form').submit();">
                                                  <?php echo e(__('Logout')); ?>

                                              </a>

                                              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                  <?php echo csrf_field(); ?>
                                              </form>
                                          </div>

                <?php endif; ?>
                                    


                    </li>

                </ul>

                <form class="top_search" action="<?php echo e(url('search')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group position-relative">
                        <input type="text" class="form-control search_main_menu" name="occupation" placeholder="search"/>
                        <button class="btn search_btn" type="submit"><i class="fas fa-search search_icon"></i></button>
                    </div>
                </form>
                <ul class="navbar-nav social_icon">
                    <li class="nav-item">
                        <a class="nav-link social_links" href="https://twitter.com">
                            <i class="fab fa-twitter social_menu"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link social_links" href="https://facebook.com">
                            <i class="fab fa-facebook-f social_menu"></i>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link social_links" href="https://instagram.com">
                            <i class="fab fa-instagram social_menu"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<?php /**PATH F:\project\htdocs\HouseKeeping\resources\views/includes/header.blade.php ENDPATH**/ ?>