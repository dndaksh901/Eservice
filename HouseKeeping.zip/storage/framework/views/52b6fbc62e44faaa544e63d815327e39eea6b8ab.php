<?php $__env->startSection('links'); ?>

 <!-- Select2 -->
 <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
 <!-- endSelect2 -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>
    .select2-container--default .select2-selection--single {
        height: auto;
        padding: 8px;
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        top: 10px;
        right: 4px;
    }

    .select2-container .select2-selection--single .select2-selection__rendered {
        padding-left: 15px;
    }
    img.profile-side-image{
        position: fixed;
        max-width: 41.5%;
        width: 100%;
    }
    .custom-control-input:checked ~ .custom-control-label::before {
    color: #fff;
    border-color: #097953;
    background-color: #097953;
}
</style>

    <div class="content-wrapper">
        <div class="row">
            <div class="col-12">
                <?php if($errors->any()): ?>

                <ul class="list-unstyled">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Error :</strong> <?php echo e($error); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <ul class="list-unstyled">
                        <li class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('error')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </li>
                    </ul>
                <?php endif; ?>
                <?php if(session()->has('success')): ?>
                    <ul class="list-unstyled">
                        <li class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('success')); ?></strong>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </li>
                    </ul>

                <?php endif; ?>
            </div>
        </div>

      <div class="row">
        <div class="col-lg-6 col-md-12 col-sm-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Vendor Personal Information</h4>
              <form action="<?php echo e(url('vendor/update-personal_detail')); ?>" method="post" class="forms-sample" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" readonly value="<?php echo e(Auth::guard('vendor')->user()->email); ?>">
                </div>

                <div class="form-group">
                    <label for="exampleInputUsername1">Username</label>
                    <input type="text" class="form-control" readonly value="<?php echo e(Auth::guard('vendor')->user()->username); ?>">
                </div>

                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" class="form-control"  name="name" value="<?php echo e(Auth::guard('vendor')->user()->name); ?>">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                  <label for="confirm_password">Mobile</label>
                  <input type="number" class="form-control" name="mobile" value="<?php echo e(Auth::guard('vendor')->user()->mobile); ?>">
                  <p id="current_password_message"></p>
                  <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <label for="confirm_password">Date of Birth</label>
                  <input type="date" class="form-control" name="dob" value="<?php echo e(Auth::guard('vendor')->user()->dob); ?>">
                  <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
            <label for="gender">Gender</label>
            <br>
                    <!-- Default inline 1-->
            <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" class="custom-control-input" id="gender1" name="gender" value="male" <?php echo e(Auth::guard('vendor')->user()->gender == 'male' ?'checked' : ''); ?>>
                <label class="custom-control-label" for="gender1">Male</label>
            </div>

            <!-- Default inline 2-->
            <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" class="custom-control-input" id="gender2" name="gender" value="female" <?php echo e(Auth::guard('vendor')->user()->gender == 'female' ?'checked' : ''); ?>>
                <label class="custom-control-label" for="gender2">Female</label>
            </div>

            <!-- Default inline 3-->
            <div class="custom-control custom-radio custom-control-inline">
                <input type="radio" class="custom-control-input" id="gender3" name="gender" value="other" <?php echo e(Auth::guard('vendor')->user()->gender == 'other' ?'checked' : ''); ?>>
                <label class="custom-control-label" for="gender3">Other</label>
            </div>
        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="file">Profile Image</label>
                    <input type="file" class="form-control" id="avatar" name="avatar">
                    <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="col-md-12 my-2">
                        <?php $avatar=Auth::guard('vendor')->user()->avatar ?? 'avatar.jpg'; ?>
                        <a href="<?php echo e(asset('vendor/vendor_image/'.$avatar)); ?>" target="_blank" title="view"><img id="preview-image-before-upload" src="<?php echo e(asset('vendor/vendor_image/'.$avatar)); ?>"
                            alt="preview image" style="max-height: 150px;"></a>
                    </div>
                  </div>

                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                <button class="btn btn-light">Cancel</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-12">
            <div><img src="<?php echo e(asset('vendor/personal-page.png')); ?>" alt="personal-page" class="img-fluid profile-side-image"></div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>


<script type="text/javascript">

var $disabledResults = $(".js-example-basic-single");
$disabledResults.select2();

    $(document).ready(function (e) {


       $('#avatar').change(function(){

        let reader = new FileReader();

        reader.onload = (e) => {

          $('#preview-image-before-upload').attr('src', e.target.result);
        }

        reader.readAsDataURL(this.files[0]);

       });

    });

</script>
  <script>
       $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        //Check current password
        function checkCurrentPassword(password){

             $.ajax({
                url:"<?php echo e(url('admin/check-current-password')); ?>",
                type:"post",
                data:{
                   'current_password' : password
                },
                success:function(response){
                    cl(response);
                    $("#current_password_message").empty();

                    if(response.status == 200){
                        $("#current_password_message").html(`<span class="text-success font-weight-bold">${response.message}</span>`)
                    }else{
                        $("#current_password_message").html(`<span class="text-danger font-weight-bold">${response.message}</span>`)
                    }
                }
             });
        }

  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('vendor.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\htdocs\HouseKeeping\resources\views/vendor/update_detail.blade.php ENDPATH**/ ?>