<?php $__env->startSection('content'); ?>
<style>
    .divider:after,
.divider:before {
content: "";
flex: 1;
height: 1px;
background: #eee;
}
.h-custom {
height: calc(100% - 73px);
}
@media (max-width: 450px) {
.h-custom {
height: 100%;
}
}
</style>

<div>
    <section class="card vh-100">
        <div class="container h-custom">
          <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-md-9 col-lg-6 col-xl-5">
              <img src="<?php echo e(asset('imgs/signin.png')); ?>" class="img-fluid" alt="Sample image">
            </div>
            <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                <?php if(isset($url)): ?>
                <form method="POST" action='<?php echo e(url("$url/login")); ?>' aria-label="<?php echo e(__('Login')); ?>">
                <?php else: ?>
                <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                <div class="d-flex flex-row align-items-center justify-content-center justify-content-lg-start">
                  <h3 class="fw-bold text-center mb-3"><?php echo e(isset($url) ? ucwords($url) : ""); ?>  <?php echo e(__('Login')); ?> </h3>
                  

                  

                  
                </div>

                

                <!-- Email input -->
                <div class="form-outline mb-4">
                  <input type="email" id="email" class="form-control form-control-lg"
                    placeholder="Enter a valid email address" name="email"/>
                  
                </div>

                <!-- Password input -->
                <div class="form-outline mb-3">
                  <input type="password" id="password" class="form-control form-control-lg"
                    placeholder="Enter password" name="password"/>
                  
                </div>

                <div class="d-flex justify-content-between align-items-center">
                  <!-- Checkbox -->
                  <div class="form-check mb-0">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                    <label class="form-check-label" for="remember">
                        <?php echo e(__('Remember Me')); ?>

                    </label>
                  </div>

                  <?php if(Route::has('password.request')): ?>
                  <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                      <?php echo e(__('Forgot Your Password?')); ?>

                  </a>
                   <?php endif; ?>
                  
                </div>

                <div class="text-center text-lg-start mt-4 pt-2">
                  <button type="submit" class="btn btn-lg"
                    style="padding-left: 2.5rem; padding-right: 2.5rem;background: var(--yellow-color);;
                    border-color:var(--yellow-color);color:#ffffff;">Login</button>
                  <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account?

                    <?php if(isset($url)): ?>
                    <a href="<?php echo e(url("$url/register")); ?>" class="link-danger"><?php echo e(isset($url) ? ucwords($url) : ""); ?> <?php echo e(__('Register')); ?></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('register')); ?>" class="link-danger"><?php echo e(isset($url) ? ucwords($url) : ""); ?> <?php echo e(__('Register')); ?></a>
                    <?php endif; ?>

                </p>
                </div>

              </form>
            </div>
          </div>
        </div>

      </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\project\htdocs\HouseKeeping\resources\views/auth/login.blade.php ENDPATH**/ ?>