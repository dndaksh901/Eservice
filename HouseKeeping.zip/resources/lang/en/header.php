<?php

return [
  
    'home' => 'Home',
    'Be Our Vendor' => 'Be Our Vendor',
    'Book a Service' => 'Book a Service',
    'help' => 'Help',
    'Customer Help Center' => 'Customer Help Center',

];